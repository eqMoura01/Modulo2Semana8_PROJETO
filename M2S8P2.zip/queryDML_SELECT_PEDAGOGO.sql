SELECT * from lab365.pedagogo;

SELECT nome_completo, situacao from lab365.pedagogo;

SELECT id, nome_completo from lab365.pedagogo WHERE situacao = FALSE;

SELECT id, telefone from lab365.pedagogo WHERE telefone = NULL;

SELECT id, telefone from lab365.pedagogo WHERE situacao != FALSE;
