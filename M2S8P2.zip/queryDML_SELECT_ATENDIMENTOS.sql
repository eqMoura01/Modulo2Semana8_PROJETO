SELECT * FROM lab365.atendimentos_pedagogicos;

SELECT descricao_atendimento FROM lab365.atendimentos_pedagogicos where categoria_atendimento = 'ADVERTENCIA';

SELECT * FROM lab365.atendimentos_pedagogicos WHERE id_aluno = 2;

SELECT situacao_atendimento FROM lab365.atendimentos_pedagogicos WHERE id_aluno = 2 AND categoria_atendimento = 'ADVERTENCIA';

SELECT id_pedagogo FROM lab365.atendimentos_pedagogicos WHERE id_aluno = 2;