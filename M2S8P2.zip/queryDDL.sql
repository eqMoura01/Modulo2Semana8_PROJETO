CREATE SCHEMA lab365;

CREATE TABLE lab365.endereco(
    id SERIAL PRIMARY KEY NOT NULL,
    cep VARCHAR(8) NOT NULL,
    logradouro VARCHAR(64) NOT NULL,
    numero_imovel INTEGER NOT NULL, 
    complemento VARCHAR(120), 
    bairro VARCHAR(64) NOT NULL,
    cidade VARCHAR(64) NOT NULL, 
    uf VARCHAR(2) NOT NULL
);

CREATE TABLE lab365.aluno(
    id SERIAL PRIMARY KEY NOT NULL,
    id_endereco INTEGER REFERENCES lab365.endereco(id) NOT NULL,
    nome_completo VARCHAR(64) NOT NULL,
    cpf VARCHAR(11) NOT NULL UNIQUE,
    data_nasc DATE NOT NULL,
    telefone VARCHAR(12),
    situacao BOOLEAN NOT NULL,
    nota_selecao NUMERIC NOT NULL
);

CREATE TABLE lab365.professor(
    id SERIAL PRIMARY KEY NOT NULL,
    id_endereco INTEGER REFERENCES lab365.endereco(id) NOT NULL,
    nome_completo VARCHAR(64) NOT NULL,
    cpf VARCHAR(11) NOT NULL UNIQUE,
    data_nasc DATE NOT NULL,
    telefone VARCHAR(12),
    situacao BOOLEAN NOT NULL,
    formacao VARCHAR(32) NOT NULL,
    experiencia VARCHAR(32) NOT NULL
);

CREATE TABLE lab365.pedagogo(
    id SERIAL PRIMARY KEY NOT NULL,
    id_endereco INTEGER REFERENCES lab365.endereco(id) NOT NULL,
    nome_completo VARCHAR(64) NOT NULL,
    cpf VARCHAR(11) NOT NULL UNIQUE,
    data_nasc DATE NOT NULL,
    telefone VARCHAR(12),
    situacao BOOLEAN NOT NULL
);


CREATE TABLE lab365.atendimentos_pedagogicos(
    id SERIAL PRIMARY KEY NOT NULL,
    id_pedagogo INTEGER REFERENCES lab365.pedagogo(id) NOT NULL,
    id_aluno INTEGER REFERENCES lab365.aluno(id) NOT NULL,
    titulo_atendimento VARCHAR(32) NOT NULL,
    descricao_atendimento VARCHAR(120) NOT NULL,
    categoria_atendimento VARCHAR(32) NOT NULL,
    situacao_atendimento BOOLEAN NOT NULL
);




