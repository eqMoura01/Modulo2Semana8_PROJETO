INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    telefone, situacao, formacao, experiencia
) VALUES (
    3, 'Robertin da 7', '11111111111', '01/03/1990', '048999999999',
    TRUE, 'BACHARELADO', 'FRONT-END'
);

INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    situacao, formacao, experiencia
) VALUES (
    4, 'Elton damassa', '22222222222', '28/02/1994',
    FALSE, 'EM FORMAÇÃO', 'FULL-STACK'
);

INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    telefone, situacao, formacao, experiencia
) VALUES (
    5, 'Jubilei Jucileia', '33333333333', '25/12/1989' , '047888888888',
    TRUE, 'DOUTORADO', 'BACK-END'
);

INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    situacao, formacao, experiencia
) VALUES (
    2, 'O carinha que mora logo ali', '44444444444', '09/10/1992',
    TRUE, 'EM FORMAÇÃO', 'FULL-STACK'
);

INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    telefone, situacao, formacao, experiencia
) VALUES (
    3, 'Terry Crews', '55555555555', '30/07/1968', '051991546805',
    FALSE, 'BACHARELADO', 'FRONT-END'
);