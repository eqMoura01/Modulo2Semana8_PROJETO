SELECT * FROM lab365.professor;

SELECT id, nome_completo FROM lab365.professor;

SELECT nome_completo, formacao FROM lab365.professor WHERE situacao = TRUE;

SELECT id, nome_completo, cpf FROM lab365.professor WHERE cpf != '11111111111';

SELECT id, nome_completo, situacao, experiencia FROM lab365.professor WHERE situacao = FALSE AND experiencia = 'FULL-STACK';