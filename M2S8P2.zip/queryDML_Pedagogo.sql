INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, telefone, situacao
) VALUES (
    2, '???', '66666666666', '01/02/1990', '085945123678', TRUE
);

INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, situacao
) VALUES (
    3, 'Miguelito Juarez Rodrigues', '77777777777', '16/01/1992', TRUE
);

INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, situacao
) VALUES (
    5, 'Jailson Frederics', '88888888888', '17/06/2000', FALSE
);

INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, situacao
) VALUES (
    4, 'Batman da silva', '99999999999', '12/04/1999', TRUE
);

INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, situacao
) VALUES (
    2, 'Rubin Barriguelo', '00000000000', '14/09/1972', FALSE
);