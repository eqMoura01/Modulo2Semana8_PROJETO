INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    complemento, bairro, cidade, uf
) VALUES (
    '88107255','Rua Olivério Sangaletti', 320,
    'Fim da rua', 'São José', 'Forquilhas', 'SC'
);

INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    bairro, cidade, uf
) VALUES (
    '88107565', 'Rua Nossa Senhora Rainha da Paz', 420,
    'Forquilhas', 'São José', 'SC'
);

INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    complemento, bairro, cidade, uf
) VALUES (
    '95680000', 'R. Teixeira Soares', 413,
    'Casa de cabeça pra baixo', 'Centro', 'Canela', 'RS'
);

INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    complemento, bairro, cidade, uf
) VALUES (
    '95680000', 'Rodovia estadual 466', 3915,
    'Um bar congelado abaixo de -10º', 'Caracol', 'Canela', 'RS'
);

INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    bairro, cidade, uf
) VALUES (
    '89135970', 'Rua Quintino Bocaiuva 230', 1893,
    'Centro', 'Apiúna', 'SC'
);