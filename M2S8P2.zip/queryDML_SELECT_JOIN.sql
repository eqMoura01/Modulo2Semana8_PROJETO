-- SELECT JOIN aluno
SELECT al.nome_completo, ap.descricao_atendimento from lab365.aluno al INNER JOIN lab365.atendimentos_pedagogicos ap ON al.id = ap.id_aluno WHERE al.id = 2;

SELECT al.nome_completo, al.id, e.bairro FROM lab365.aluno al INNER JOIN lab365.endereco e ON e.id = al.id_endereco WHERE al.id = 2;

-- SELECT JOIN professor
SELECT e.* FROM lab365.professor pr INNER JOIN lab365.endereco e ON e.id = pr.id_endereco WHERE pr.nome_completo = 'Robertin da 7';

SELECT * FROM lab365.professor pr INNER JOIN lab365.endereco e ON e.id = pr.id_endereco WHERE e.uf = 'SC';

-- SELECT JOIN pedagogo
SELECT COUNT(*) FROM lab365.pedagogo ped INNER JOIN lab365.endereco e ON e.id = ped.id_endereco WHERE e.uf != 'SC';

SELECT ped.cpf, e.cidade FROM lab365.pedagogo ped INNER JOIN lab365.endereco e ON e.id = ped.id_endereco WHERE e.cidade != 'São José';

-- SELECT JOIN atendimento_pedagogico
SELECT COUNT(*) FROM lab365.atendimentos_pedagogicos ap INNER JOIN lab365.aluno a ON a.id = ap.id_aluno;

SELECT COUNT(*) FROM lab365.atendimentos_pedagogicos ap INNER JOIN lab365.aluno a ON a.id = ap.id_aluno WHERE ap.categoria_atendimento = 'ADVERTENCIA';