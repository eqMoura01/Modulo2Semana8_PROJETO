INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    2, 2, 'ATENDIMENTO 01', 'ALUNO 2 jogando lixo nos amiguinhos', 'ADVERTENCIA', TRUE
);

INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    2, 3, 'ATENDIMENTO ESPECIAL', 'ALUNO 3 necessita de acompanhamento de 2º professor', 'CONSULTORIA', TRUE
);

INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    3, 5, 'ATENDIMENTO EXTRA AULA', 'O aluno pediu auxilio em horario fora de aula', 'AJUDA', TRUE
);

INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    5, 2, 'CONTATO COM RESPONSAVEIS', 'O aluno não para quieto em sala de aula', 'ADVERTENCIA', TRUE
);

INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    4, 4, 'ATENDIMENTO PSICOLOGICO', 'Depois de sofrer com bullying precisou de ajuda', 'SUPORTE PSICICOLOGICO', TRUE
);