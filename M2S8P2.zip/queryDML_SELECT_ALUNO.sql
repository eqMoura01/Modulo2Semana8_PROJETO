SELECT nome_completo FROM lab365.aluno;

SELECT nome_completo, data_nasc FROM lab365.aluno;

SELECT nome_completo, cpf FROM lab365.aluno where id <= 3;

SELECT data_nasc FROM lab365.aluno where nome_completo = 'Victor Leandro Vieira Mora';

SELECT nome_completo FROM lab365.aluno where id = 3;