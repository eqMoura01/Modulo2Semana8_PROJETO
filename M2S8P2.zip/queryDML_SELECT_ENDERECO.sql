SELECT * from lab365.endereco;

SELECT cep from lab365.endereco where uf = 'SC';

SELECT cep, cidade, complemento from lab365.endereco where uf = 'RS';

SELECT logradouro, numero_imovel from lab365.endereco where id > 2;

SELECT id, uf from lab365.endereco;

