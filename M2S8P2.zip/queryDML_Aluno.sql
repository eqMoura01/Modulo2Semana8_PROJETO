INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    telefone, situacao, nota_selecao
) VALUES (
    2, 'Victor Leandro Vieira Mora', '10010010069', '2001/03/27',
    '048996512337', TRUE ,10
);

INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    situacao, nota_selecao
) VALUES (
    2, 'Godofredo Godoberto', '83706920333', '1995/05/25', 
    FALSE, 4
);

INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    telefone, situacao, nota_selecao
) VALUES (
    3, 'Lorotin da Silva Ramos', '33841675034',
    '1987/04/18', '047991487561', FALSE, 8
);

INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    situacao, nota_selecao
) VALUES (
    4, 'Bruxa de Blair', '69476228083', '1782/03/21', TRUE, 10
);

INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    situacao, nota_selecao
) VALUES (
    6, 'Carlos Gandolf', '21505368030' , 
    '2003/02/27', TRUE, 7
);