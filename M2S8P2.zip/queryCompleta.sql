-- DDL
CREATE DATABASE labschool;

CREATE SCHEMA lab365;

CREATE TABLE lab365.endereco(
    id SERIAL PRIMARY KEY NOT NULL,
    cep VARCHAR(8) NOT NULL,
    logradouro VARCHAR(64) NOT NULL,
    numero_imovel INTEGER NOT NULL, 
    complemento VARCHAR(120), 
    bairro VARCHAR(64) NOT NULL,
    cidade VARCHAR(64) NOT NULL, 
    uf VARCHAR(2) NOT NULL
);

CREATE TABLE lab365.aluno(
    id SERIAL PRIMARY KEY NOT NULL,
    id_endereco INTEGER REFERENCES lab365.endereco(id) NOT NULL,
    nome_completo VARCHAR(64) NOT NULL,
    cpf VARCHAR(11) NOT NULL UNIQUE,
    data_nasc DATE NOT NULL,
    telefone VARCHAR(12),
    situacao BOOLEAN NOT NULL,
    nota_selecao NUMERIC NOT NULL
);

CREATE TABLE lab365.professor(
    id SERIAL PRIMARY KEY NOT NULL,
    id_endereco INTEGER REFERENCES lab365.endereco(id) NOT NULL,
    nome_completo VARCHAR(64) NOT NULL,
    cpf VARCHAR(11) NOT NULL UNIQUE,
    data_nasc DATE NOT NULL,
    telefone VARCHAR(12),
    situacao BOOLEAN NOT NULL,
    formacao VARCHAR(32) NOT NULL,
    experiencia VARCHAR(32) NOT NULL
);

CREATE TABLE lab365.pedagogo(
    id SERIAL PRIMARY KEY NOT NULL,
    id_endereco INTEGER REFERENCES lab365.endereco(id) NOT NULL,
    nome_completo VARCHAR(64) NOT NULL,
    cpf VARCHAR(11) NOT NULL UNIQUE,
    data_nasc DATE NOT NULL,
    telefone VARCHAR(12),
    situacao BOOLEAN NOT NULL
);

CREATE TABLE lab365.atendimentos_pedagogicos(
    id SERIAL PRIMARY KEY NOT NULL,
    id_pedagogo INTEGER REFERENCES lab365.pedagogo(id) NOT NULL,
    id_aluno INTEGER REFERENCES lab365.aluno(id) NOT NULL,
    titulo_atendimento VARCHAR(32) NOT NULL,
    descricao_atendimento VARCHAR(120) NOT NULL,
    categoria_atendimento VARCHAR(32) NOT NULL,
    situacao_atendimento BOOLEAN NOT NULL
);

--DML

--DML INSERT endereco
INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    complemento, bairro, cidade, uf
) VALUES (
    '88107255','Rua Olivério Sangaletti', 320,
    'Fim da rua', 'São José', 'Forquilhas', 'SC'
);

INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    bairro, cidade, uf
) VALUES (
    '88107565', 'Rua Nossa Senhora Rainha da Paz', 420,
    'Forquilhas', 'São José', 'SC'
);

INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    complemento, bairro, cidade, uf
) VALUES (
    '95680000', 'R. Teixeira Soares', 413,
    'Casa de cabeça pra baixo', 'Centro', 'Canela', 'RS'
);

INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    complemento, bairro, cidade, uf
) VALUES (
    '95680000', 'Rodovia estadual 466', 3915,
    'Um bar congelado abaixo de -10º', 'Caracol', 'Canela', 'RS'
);

INSERT INTO lab365.endereco(
    cep, logradouro, numero_imovel,
    bairro, cidade, uf
) VALUES (
    '89135970', 'Rua Quintino Bocaiuva 230', 1893,
    'Centro', 'Apiúna', 'SC'
);

--DML INSERT aluno
INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    telefone, situacao, nota_selecao
) VALUES (
    2, 'Victor Leandro Vieira Mora', '10010010069', '2001/03/27',
    '048996512337', TRUE ,10
);

INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    situacao, nota_selecao
) VALUES (
    2, 'Godofredo Godoberto', '83706920333', '1995/05/25', 
    FALSE, 4
);

INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    telefone, situacao, nota_selecao
) VALUES (
    3, 'Lorotin da Silva Ramos', '33841675034',
    '1987/04/18', '047991487561', FALSE, 8
);

INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    situacao, nota_selecao
) VALUES (
    4, 'Bruxa de Blair', '69476228083', '1782/03/21', TRUE, 10
);

INSERT INTO lab365.aluno(
    id_endereco, nome_completo, cpf, data_nasc, 
    situacao, nota_selecao
) VALUES (
    5, 'Carlos Gandolf', '21505368030' , 
    '2003/02/27', TRUE, 7
);

--DML INSERT pedagogo
INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, telefone, situacao
) VALUES (
    2, '???', '66666666666', '01/02/1990', '085945123678', TRUE
);

INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, situacao
) VALUES (
    3, 'Miguelito Juarez Rodrigues', '77777777777', '16/01/1992', TRUE
);

INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, situacao
) VALUES (
    5, 'Jailson Frederics', '88888888888', '17/06/2000', FALSE
);

INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, situacao
) VALUES (
    4, 'Batman da silva', '99999999999', '12/04/1999', TRUE
);

INSERT INTO lab365.pedagogo(
    id_endereco, nome_completo, cpf, data_nasc, situacao
) VALUES (
    2, 'Rubin Barriguelo', '00000000000', '14/09/1972', FALSE
);

--DML INSERT professor
INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    telefone, situacao, formacao, experiencia
) VALUES (
    3, 'Robertin da 7', '11111111111', '01/03/1990', '048999999999',
    TRUE, 'BACHARELADO', 'FRONT-END'
);

INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    situacao, formacao, experiencia
) VALUES (
    4, 'Elton damassa', '22222222222', '28/02/1994',
    FALSE, 'EM FORMAÇÃO', 'FULL-STACK'
);

INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    telefone, situacao, formacao, experiencia
) VALUES (
    5, 'Jubilei Jucileia', '33333333333', '25/12/1989' , '047888888888',
    TRUE, 'DOUTORADO', 'BACK-END'
);

INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    situacao, formacao, experiencia
) VALUES (
    2, 'O carinha que mora logo ali', '44444444444', '09/10/1992',
    TRUE, 'EM FORMAÇÃO', 'FULL-STACK'
);

INSERT INTO lab365.professor(
    id_endereco, nome_completo, cpf, data_nasc,
    telefone, situacao, formacao, experiencia
) VALUES (
    3, 'Terry Crews', '55555555555', '30/07/1968', '051991546805',
    FALSE, 'BACHARELADO', 'FRONT-END'
);

--DML INSERT atendimentos_pedagogicos
INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    2, 2, 'ATENDIMENTO 01', 'ALUNO 2 jogando lixo nos amiguinhos', 'ADVERTENCIA', TRUE
);

INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    2, 3, 'ATENDIMENTO ESPECIAL', 'ALUNO 3 necessita de acompanhamento de 2º professor', 'CONSULTORIA', TRUE
);

INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    3, 5, 'ATENDIMENTO EXTRA AULA', 'O aluno pediu auxilio em horario fora de aula', 'AJUDA', TRUE
);

INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    5, 2, 'CONTATO COM RESPONSAVEIS', 'O aluno não para quieto em sala de aula', 'ADVERTENCIA', TRUE
);

INSERT INTO lab365.atendimentos_pedagogicos(
    id_pedagogo, id_aluno, titulo_atendimento, descricao_atendimento, categoria_atendimento,
    situacao_atendimento
) VALUES (
    4, 4, 'ATENDIMENTO PSICOLOGICO', 'Depois de sofrer com bullying precisou de ajuda', 'SUPORTE PSICICOLOGICO', TRUE
);

-- SELECT aluno
SELECT nome_completo FROM lab365.aluno;

SELECT nome_completo, data_nasc FROM lab365.aluno;

SELECT nome_completo, cpf FROM lab365.aluno where id <= 3;

SELECT data_nasc FROM lab365.aluno where nome_completo = 'Victor Leandro Vieira Mora';

SELECT nome_completo FROM lab365.aluno where id = 3;

-- SELECT atendimentos_pedagogicos
SELECT * FROM lab365.atendimentos_pedagogicos;

SELECT descricao_atendimento FROM lab365.atendimentos_pedagogicos where categoria_atendimento = 'ADVERTENCIA';

SELECT * FROM lab365.atendimentos_pedagogicos WHERE id_aluno = 2;

SELECT situacao_atendimento FROM lab365.atendimentos_pedagogicos WHERE id_aluno = 2 AND categoria_atendimento = 'ADVERTENCIA';

SELECT id_pedagogo FROM lab365.atendimentos_pedagogicos WHERE id_aluno = 2;

-- SELECT endereco
SELECT * from lab365.endereco;

SELECT cep from lab365.endereco where uf = 'SC';

SELECT cep, cidade, complemento from lab365.endereco where uf = 'RS';

SELECT logradouro, numero_imovel from lab365.endereco where id > 2;

SELECT id, uf from lab365.endereco;

-- SELECT pedagogo
SELECT * from lab365.pedagogo;

SELECT nome_completo, situacao from lab365.pedagogo;

SELECT id, nome_completo from lab365.pedagogo WHERE situacao = FALSE;

SELECT id, telefone from lab365.pedagogo WHERE telefone = NULL;

SELECT id, telefone from lab365.pedagogo WHERE situacao != FALSE;

-- SELECT professor
SELECT * FROM lab365.professor;

SELECT id, nome_completo FROM lab365.professor;

SELECT nome_completo, formacao FROM lab365.professor WHERE situacao = TRUE;

SELECT id, nome_completo, cpf FROM lab365.professor WHERE cpf != '11111111111';

SELECT id, nome_completo, situacao, experiencia FROM lab365.professor WHERE situacao = FALSE AND experiencia = 'FULL-STACK';

-- SELECT JOIN aluno
SELECT al.nome_completo, ap.descricao_atendimento from lab365.aluno al INNER JOIN lab365.atendimentos_pedagogicos ap ON al.id = ap.id_aluno WHERE al.id = 2;

SELECT al.nome_completo, al.id, e.bairro FROM lab365.aluno al INNER JOIN lab365.endereco e ON e.id = al.id_endereco WHERE al.id = 2;

-- SELECT JOIN professor
SELECT e.* FROM lab365.professor pr INNER JOIN lab365.endereco e ON e.id = pr.id_endereco WHERE pr.nome_completo = 'Robertin da 7';

SELECT * FROM lab365.professor pr INNER JOIN lab365.endereco e ON e.id = pr.id_endereco WHERE e.uf = 'SC';

-- SELECT JOIN pedagogo
SELECT COUNT(*) FROM lab365.pedagogo ped INNER JOIN lab365.endereco e ON e.id = ped.id_endereco WHERE e.uf != 'SC';

SELECT ped.cpf, e.cidade FROM lab365.pedagogo ped INNER JOIN lab365.endereco e ON e.id = ped.id_endereco WHERE e.cidade != 'São José';

-- SELECT JOIN atendimento_pedagogico
SELECT COUNT(*) FROM lab365.atendimentos_pedagogicos ap INNER JOIN lab365.aluno a ON a.id = ap.id_aluno;

SELECT COUNT(*) FROM lab365.atendimentos_pedagogicos ap INNER JOIN lab365.aluno a ON a.id = ap.id_aluno WHERE ap.categoria_atendimento = 'ADVERTENCIA';
